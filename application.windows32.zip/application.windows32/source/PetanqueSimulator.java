import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import papaya.*; 
import ddf.minim.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class PetanqueSimulator extends PApplet {

/*
Le Main du programme. 
 Setup est appelee une fois
 Draw et keyPressed sont executees automatiquement a chaque frame
 * Maxime Touroute
 * Nicolas Sintes
 * Vincent Montalieu
 * Avril 2015
 */

public void setup() 
{
  // Ouverture de la fen\u00eatre
  size(window_size_x, window_size_y);
  background(0);
  stroke(255);
  frameRate(framerate);
  setup_game();
}



public void draw() {

  // Mise \u00e0 jour des donn\u00e9es du jeu.
  update_game();

  // Dessin de la fen\u00eatre

    if (GAME_STATE == START_MENU) 
  {
    draw_menu();
  } else
  {
    draw_game();
  }
}


/**
 * Gestion des \u00e9v\u00e8nements clavier
 */
public void keyPressed() {

  if (GAME_STATE == START_MENU) 
  {
    if (key == 'x') {
      init_game();
    }
  } else if (GAME_STATE == INIT_LANCER) {
    if (key == CODED && keyCode == UP) // monter l'angle
    {
      player_angle_dattaque += 2;
      if (player_angle_dattaque > 80) player_angle_dattaque = 80; // Limite
      play_roll_fx();
      // Faire tout les
    } else if (key == CODED && keyCode == DOWN) // baisser l'angle
    {
      player_angle_dattaque -= 2;
      if (player_angle_dattaque < -80) player_angle_dattaque = -80; // Limite
      play_roll_fx();
    } else if (key == CODED && keyCode == LEFT) // Baisser player_force
    {
      player_force -= 0.2f;
      if (player_force < 1) player_force = 1; // Limite
      play_roll_fx();
    } else if (key == CODED && keyCode == RIGHT) // Monter player_force
    {
      player_force += 0.2f;
      if (player_force > 10) player_force = 10; // Limite
      play_roll_fx();
    } else if (key == 'c') // Le Cheat Mode
    {
      if (CHEAT_MODE) CHEAT_MODE = false;
      else CHEAT_MODE = true;
    }

    if (key == ' ') // Lancer la boule
    {
      commande = new Commande();
      commande.set_conditions_initiales(player_force, player_angle_dattaque);
      commande.compute_trajectoire();

      if (CHEAT_MODE) commande.compute_cheatmode();
      // commande.compute_cheatmode(); 



      GAME_STATE = LANCER_BOULE;
    }
  } else if (GAME_STATE == END_GAME)
  {
    if (key == 't') // Retour au menu principal
    {
      init_game();
    }
  }

  key = 0; // Nettoyage de l'entr\u00e9e sur key
}


public void stop()
{
  stop_sound();
}



/*
Gestion de la commande manuelle et de la commande par boucle ouverte (le mode triche)
 * Maxime Touroute
 * Nicolas Sintes
 * Vincent Montalieu
 * Avril 2015
 */

class Commande
{

  // Variables de conditions initiales
  float masse = 0.8f;
  float gterre = 9.81f;

  // L'horizon pour la boucle ouverte
  int valeur_h = 50;

  // Stockage du nombre d'echantillons traites dans chaque cas
  int instant_fin_commande_manuelle;
  int instant_fin_commande_triche;

  // Stockage des donnees de trajectoire: coordonnees x et y, vitesse x et y
  // Stockees dans des tableaux a taille fixe. Limite imposee a 2000

  // Les deux vecteurs qui stockent les coordonnees de la trajectoire 
  float[] coordonnees_trajectoire_x = new float[2000];
  float[] coordonnees_trajectoire_y = new float[2000];

  // M\u00eames vecteurs, pour le mode triche (La boucle ouverte)
  float[] coordonnees_trajectoire_x_triche = new float[2000];
  float[] coordonnees_trajectoire_y_triche = new float[2000];

  // On stocke la vitesse de la boule a chaque instant
  float[] vitesse_trajectoire_x = new float[2000];
  float[] vitesse_trajectoire_y = new float[2000];

  // L'instant t d'execution
  int instant_t = 0;


  // Nos equations discretes 

  // MAtrice Ad 4x4
  float[][] Ad = { 
    {
      1.0f, 0.03f, 0, 0
    }
    , 
    {
      0.0f, 1.0f, 0.0f, 0.0f
    }
    , 
    {
      0.0f, 0.0f, 1.0f, 0.03f
    }
    , 
    {
      0.0f, 0.0f, 0.0f, 1.0f
    }
  }; 

  // MAtrice Bd 2x'4
  float[][] Bd = { 
    {
      0.00045f, 0
    }
    , {
      0.03f, 0
    }
    , {
      0, 0.00045f
    }
    , {
      0, 0.03f
    }
  }; 

  // Le vecteur de commande
  float[][] a = { 
    {
      0
    }
    , 
    {
      -gterre
    }
  };


  // Vecteur initial
  float[][] X0 = {
    {
      0
    }
    , 
    {
      0
    }
    , 
    {
      0
    }
    , 
    {
      0
    }
  }; 


  /*
  Initialisation des conditions initiales
   @params force, la force du lancer
   @p_angle_dattaque l'angle d'attaque du lancer
   */
  public void set_conditions_initiales(float force, float p_angle_dattaque)
  {
    float angle_dattaque = p_angle_dattaque;

    // Calcul de la vitesse d'attaque
    float v0x = force * cos( radians(angle_dattaque) );
    float v0y = force * sin( radians(angle_dattaque) );

    // Vecteur de conditions initiales
    X0[0][0] = 0;
    X0[1][0] = v0x;
    X0[2][0] = HAUTEUR_INITIALE;
    X0[3][0] = v0y;
  }


  /*
  * Calcule tous les points de trajectoire, et stocke les r\u00e9ultats 
   * dans les tableaux coordonnees_trajectoire_x et coordonnees_trajectoire_y
   */
  public void compute_trajectoire()
  {

    // Initialisation du prochain vecteur \u00e0 calculer
    float[][] Xsuivant = {  
      {
        0
      }
      , 
      {
        0
      }
      , 
      {
        0
      }
      , 
      {
        0
      }
    };

    // Le X pr\u00e9c\u00e9dent, qui est une copie du vecteur initial X0
    float[][] X = new float[4][1];    
    X[0][0] = X0[0][0];
    X[1][0] = X0[1][0];
    X[2][0] = X0[2][0];
    X[3][0] = X0[3][0];

    // Stockage des premi\u00e8res valeurs
    coordonnees_trajectoire_x[0] = X[0][0]; // x
    coordonnees_trajectoire_y[0] = X[2][0]; // y

    while ( X[2][0] > 0 ) // Tant que la position en y est sup\u00e9rieure \u00e0 0 (pas encore par terre)
    {
      // on r\u00e9initialise Xsuivant avant de r\u00e9-it\u00e9rer la boucle
      Xsuivant[0][0] = 0;
      Xsuivant[1][0] = 0;
      Xsuivant[2][0] = 0;
      Xsuivant[3][0] = 0;

      instant_t++;

      // Produit matriciel inspir\u00e9 de celui du code Scilab

      for (int i = 0; i < 4; i++) // Les 4 lignes
      {
        for (int j = 0; j < 4; j++) // les 4 colonnes
        {
          Xsuivant[i][0] += Ad[i][j]*X[j][0] ;//+ Bd*a;
        }
      }

      for (int i = 0; i < 4; i++) // ajout du terme Bd*a;
      {
        for (int j = 0; j < 2; j++)
        {

          Xsuivant[i][0] += Bd[i][j]*a[j][0];
        }
      }

      // L'ancien X devient le nouveau X.
      X[0][0] = Xsuivant[0][0];
      X[1][0] = Xsuivant[1][0];
      X[2][0] = Xsuivant[2][0];
      X[3][0] = Xsuivant[3][0];

      // Stockage des nouvelles coordonn\u00e9es de trajectoire
      coordonnees_trajectoire_x[instant_t] = Xsuivant[0][0];
      coordonnees_trajectoire_y[instant_t] = Xsuivant[2][0];

      // Stockage de la vitesse
      vitesse_trajectoire_x[instant_t] = Xsuivant[1][0];
      vitesse_trajectoire_y[instant_t] = Xsuivant[3][0];
    }

    // On stocke le nombre d'\u00e9chantillons cr\u00e9\u00e9s
    instant_fin_commande_manuelle = instant_t;
  }

  /*
  * La commande par boucle ouverte (retour d'\u00e9tat)
   * Calcule tous les points de trajectoire, et stocke les r\u00e9ultats 
   * dans les tableaux coordonnees_trajectoire_x_triche et coordonnees_trajectoire_y_triche
   */
  public void compute_cheatmode()
  {
    // En entr\u00e9e, le vecteur X0, vecteur initial au lancement de la boule
    float[][] XDebutTriche = {
      {
        X0[0][0]
      }
      , {
        X0[1][0]
      }
      , {
        X0[2][0]
      }
      , {
        X0[3][0]
      }
    }; 


    print("position cochonnet:", position_cochonnet, "\n");

    // Le vecteur \u00e0 atteindre en fin de parcours
    float[][] Xh = {
      {
        position_cochonnet
      }
      , {
        0
      }
      , {
        0
      }
      , {
        -5 // Pour \u00e9viter que la balle arrive par sous-terre, on impose une petite vitesse negative
      }
    };   

    // en h \u00e9tapes
    int h = valeur_h;

    // Matrice de gouvernabilit\u00e9 : les premi\u00e8res valeurs c'est Bd
    float[][] G = new float[4][2*h]; // G est une matrice contenant une liste de vecteurs 4 (sur chaque colonne) 


    // Code Scilab: G = Bd
    G[0][(2*h)-2] = Bd[0][0];//0.00045;
    G[1][(2*h)-2] = Bd[1][0];//0.03;
    G[2][(2*h)-2] = Bd[2][0];//0;
    G[3][(2*h)-2] = Bd[3][0];//0;

    G[0][(2*h)-1] = Bd[0][1];//0;
    G[1][(2*h)-1] = Bd[1][1];//0;
    G[2][(2*h)-1] = Bd[2][1];//0.00045;
    G[3][(2*h)-1] = Bd[3][1];//0.03;


    /**************************** Calcul de la matrice de gouvernabilit\u00e9 *******************************/

    // Code Scilab
    /*
    for k=1:h-1
     G=[(Ad^k)*Bd,G]; // On 
     end*/

    // Creation du Ad^k
    float[][] Adk = new float[4][4];

    // Qu'on initialise \u00e0 Ad
    for (int i = 0; i < 4; i++)
      for (int j = 0; j < 4; j++)
        Adk[i][j]=Ad[i][j];


    // Indice colonne o\u00f9 il faut \u00e9crire la valeur (on remplit G \u00e0 partir de la fin)
    int indice_courant_de_G = (2*h)-3; 

    for (int k = 1; k < h; k++)
    {

      // On multiplie Adk par Ad voil\u00e0.
      if (k != 1)
      {
        // Le Adk d'avant.
        float[][] prev_Adk = Adk;

        // Calcul du Adk
        for (int i = 0; i < 4; i++) // Les 4 lignes
        {
          for (int j = 0; j < 4; j++) // les 4 colonnes
          {
            // calcul de la valeur en ce point
            float sum = 0;

            for (int p = 0; p < 4; p++)
            {
              // Adk ligne i colonne j est \u00e9gal \u00e0 la la somme des produits de prev_adk[i][j]*Ad[k]
              sum = sum + prev_Adk[i][p]*Ad[p][j] ;
            }

            Adk[i][j] = sum;
          }
        }
      }


      // Calcul de la matrice 4x2 \u00e0 ajouter dans G

      float[][] temp_G = new float[4][2];

      for (int i = 0; i < 4; i++) // Les 4 lignes
      {
        for (int j = 0; j < 2; j++) // les 2 colonnes
        {
          float sum = 0;

          for (int p = 0; p < 4; p++)
          {
            sum += Adk[i][p]*Bd[p][j];
          }
          temp_G[i][j] = sum;
        }
      }

      // Derniere etape: concatener la matrice temp_G \u00e0 G.

      for (int i = 0; i < 4; i++)
      {
        G[i][indice_courant_de_G] = temp_G[i][1];
      }

      indice_courant_de_G--;

      for (int i = 0; i < 4; i++)
      {
        G[i][indice_courant_de_G] = temp_G[i][0];
      }

      indice_courant_de_G--;
    }

    // On a notre matrice de gouvernabilit\u00e9.

    print("final G\n");
    Mat.print(G, 5);


    /************************************************* Calcul de y ************************************/

    // Code Scilab
    //y = Xh - (Ad^h) * X0; // y, le vecteur final qu'on veut atteindre ?


    float[][] y = { 
      {
        0
      }
      , {
        0
      }
      , {
        0
      }
      , {
        0
      }
    };

    // Initialisation du vecteur y avec Xh (le vecteur qu'on veut atteindre)
    y[0][0] = Xh[0][0];
    y[1][0] = Xh[1][0];
    y[2][0] = Xh[2][0];
    y[3][0] = Xh[3][0];

    // On reprend Adk et on le multiplie par Ad une fois de + pour obtenir Ad^h
    {

      // Le Adk d'avant.
      float[][] prev_Adk = Adk;

      // Calcul du Adk
      for (int i = 0; i < 4; i++) // Les 4 lignes
      {
        for (int j = 0; j < 4; j++) // les 4 colonnes
        {
          // calcul de la valeur en ce point
          float sum = 0;

          for (int p = 0; p < 4; p++)
          {
            // Adk ligne i colonne j est \u00e9gal \u00e0 la la somme des produits de prev_adk[i][j]*Ad[k]
            sum = sum + prev_Adk[i][p]*Ad[p][j] ;
          }

          Adk[i][j] = sum;
        }
      }
    }


    // Code Scilab: Ad^h*X0
    float[][] temp_result = { 
      {
        0
      }
      , {
        0
      }
      , {
        0
      }
      , {
        0
      }
    };

    for (int i = 0; i < 4; i++) // Les 4 lignes
    {
      for (int j = 0; j < 4; j++) // les 4 colonnes
      {
        temp_result[i][0] += Adk[i][j]*XDebutTriche[j][0] ;
      }
    }

    y[0][0] -= temp_result[0][0];
    y[1][0] -= temp_result[1][0];
    y[2][0] -= temp_result[2][0];
    y[3][0] -= temp_result[3][0];

    // On a y.

    print("\ny\n");
    Mat.print(y, 5);

    /* Code Scilab :
     Gt = G'; // G' donne la transpos\u00e9e de G
     u = (Gt * inv(G * Gt)) * y; 
     */

    // La transpos\u00e9e
    float[][] Gt = new float[2*h][4];

    for (int i = 0; i < 2*h; i++) // 2*h lignes dans la matrice transpos\u00e9e
      for (int j = 0; j < 4; j++ ) // et 4 colonnes
        Gt[i][j] = G[j][i];

    // Derniere etape: le vecteur de commande qui remplacera notre a: u = (Gt * inv(G * Gt)) * y; 

    //Code scilab: Gt * inv(G * Gt)

    float[][] GxGt = new float[4][4];

    for (int i = 0; i < 4; i++) // Les 4 lignes
    {
      for (int j = 0; j < 4; j++) // les 4 colonnes
      {
        float sum = 0.0f;
        for (int p = 0; p < 2*h; p++)
        {
          sum += G[i][p]*Gt[p][j];
        }
        GxGt[i][j] = sum;
      }
    }

    // On fait l'inverse de la matrice avec une bibliotheque processing

    float[][] invGxGt = Mat.inverse(GxGt);

    //  Gt*invGxGt
    float[][] GtxinvGxGt = new float[2*h][4];

    for (int i = 0; i < 2*h; i++) // Les 2*h lignes
    {
      for (int j = 0; j < 4; j++) // les 4 colonnes
      {
        float sum = 0;
        // \u00e0 chaque \u00e9tape, 
        for (int p = 0; p < 4; p++)
        {
          sum += Gt[i][p]*invGxGt[j][p];
        }
        GtxinvGxGt[i][j] = sum;
      }
    }


    // Plus qu'\u00e0 multiplier ce terme par le vecteur y 
    float[][] u = new float[2*h][1];

    for (int i = 0; i < 2*h; i++) // Les 2*h lignes
    {
      float sum = 0;

      for (int p = 0; p < 4; p++)
      {
        sum += GtxinvGxGt[i][p]*y[p][0];
      }
      u[i][0] = sum;
    }

    // On a notre vecteur de commande
    print("\nu!\n");
    Mat.print(u, 5);



    /****************************************** Calcul de la nouvelle trajectoire ********************************************/

    // Initialisation du prochain vecteur \u00e0 calculer
    float[][] Xsuivant = {  
      {
        0
      }
      , 
      {
        0
      }
      , 
      {
        0
      }
      , 
      {
        0
      }
    };

    // Le X pr\u00e9c\u00e9dent, qu'on initialise aux valeurs du premier point
    float[][] X = new float[4][1];

    X[0][0] = XDebutTriche[0][0]; 
    X[1][0] = XDebutTriche[1][0]; 
    X[2][0] = XDebutTriche[2][0]; 
    X[3][0] = XDebutTriche[3][0]; 

    // Stockage des premi\u00e8res valeurs
    coordonnees_trajectoire_x_triche[0] = X[0][0]; // x
    coordonnees_trajectoire_y_triche[0] = X[2][0]; // y

    // On commence \u00e0 l'instant temps=0
    instant_t = temps;

    for (int k = 0; k < 2*h; k+=2) 
    {
      // on r\u00e9initialise Xsuivant avant de r\u00e9-it\u00e9rer la boucle
      Xsuivant[0][0] = 0;
      Xsuivant[1][0] = 0;
      Xsuivant[2][0] = 0;
      Xsuivant[3][0] = 0;

      // On incr\u00e9mente l'instant t
      instant_t++;

      // Produit matriciel inspir\u00e9 de celui du code Scilab

      for (int i = 0; i < 4; i++) // Les 4 lignes
      {
        for (int j = 0; j < 4; j++) // les 4 colonnes
        {
          Xsuivant[i][0] += Ad[i][j]*X[j][0] ;//+ Bd*a;
        }
      }

      float[][] vecteur_commande = new float[2][1];

      vecteur_commande[0][0] = u[k][0];

      // On initialise le vecteur de commande qui remplace le vecteur a
      vecteur_commande[1][0] = u[k+1][0];


      for (int i = 0; i < 4; i++) // ajout du terme Bd*u;
      {
        for (int j = 0; j < 2; j++)
        {

          Xsuivant[i][0] += Bd[i][j]*vecteur_commande[j][0];
        }
      }

      // L'ancien X devient le nouveau X.
      X[0][0] = Xsuivant[0][0];
      X[1][0] = Xsuivant[1][0];
      X[2][0] = Xsuivant[2][0];
      X[3][0] = Xsuivant[3][0];



      // Stockage des nouvelles coordonn\u00e9es de trajectoire
      coordonnees_trajectoire_x_triche[instant_t] = Xsuivant[0][0];
      coordonnees_trajectoire_y_triche[instant_t] = Xsuivant[2][0];

      // Stockage de la vitesse
      vitesse_trajectoire_x[instant_t] = Xsuivant[1][0];
      vitesse_trajectoire_y[instant_t] = Xsuivant[3][0];
    }

    // On stocke l'instant de fin
    instant_fin_commande_triche = instant_t;
  }  // Fin  de m\u00e9thode
}

/*
  * Les m\u00e9thodes de dessin du jeu
 * Maxime Touroute
 * Nicolas Sintes
 * Vincent Montalieu
 * Avril 2015
 */

// Un compteur pour des effets anim\u00e9s
float compteur_dessin = 1;
float seconde = 0;

/*
Dessin de l'ecran d'accueil
 */
public void draw_menu()
{

  float cl = sin(compteur_dessin/40);
  compteur_dessin++;

  if (compteur_dessin % PApplet.parseInt(framerate/3) == 0) seconde++;

  background(220+cl*100, 200+cl*80, 200+cl*10);

  image(menu_background,0,0);
  image(menu_img, 0, 0);

  if (seconde % 2 == 0) image(menu_x, 0, 0);
}

/*
Dessin du jeu
 */
public void draw_game()
{
  // Le dessin du jeu depend de l'etat dans lequel est le jeu (GAME_STATE)

  // INIT_LANCER : la boule n'a pas encore ete lancee
  if (GAME_STATE == INIT_LANCER)
  {

    background(background_img);
    drawSpeedVector();
    draw_boule();
    draw_cochonnet();
    draw_legende();
    draw_texts();
  }

  // La boule est en vol
  else if (GAME_STATE == LANCER_BOULE)
  {
    background(background_img);
    draw_trajectoire();

    if (CHEAT_MODE)
    {
      draw_trajectoire_triche();
      if (temps < commande.instant_fin_commande_triche)
        draw_reacteurs();
    }

    drawSpeedVector();
    draw_boule();
    draw_cochonnet();

    draw_legende();
    draw_texts();
  }
  // STATE : Fin du jeu: affichage du score
  else if (GAME_STATE == END_GAME) 
  { 
    // Petit effet de couleur clignotante sur le score
    if (compteur_dessin < 10) fill(255, 0, 0);
    else if (compteur_dessin >= 10 && compteur_dessin < 20) fill(0);
    else if (compteur_dessin < 30) fill(255, 0, 0);
    else fill(0);

    compteur_dessin+=7;

    textSize(60);
    textAlign(CENTER, CENTER);

    if (position_boule_x*SCALE < window_size_x+10)
    {
      text("SCORE:" + PApplet.parseInt(score) + "%", 400, 120);
    } else
    {
      text("OUT OF BOUNDS !", 400, 120);
    }

    fill(0, 0, 0);
    textSize(25);
    textAlign(CENTER, CENTER);
    text("TRY AGAIN? [T]", 400, 170); 
    fill(0, 0, 0);
  }
}

/*
Dessine la trajectoire de la boule
 */
public void draw_trajectoire()
{

  // Affichage de la trajectoire au fur et a mesure de l'avancement de la boule
  for (int i = 0; (!CHEAT_MODE && i < temps) || (CHEAT_MODE && ( ( i < temps && i < commande.instant_fin_commande_manuelle ) || (i >= commande.instant_fin_commande_triche && i < commande.instant_fin_commande_manuelle) )  ); i++)
  {
    // Dessin de la ligne
    stroke(214, 0, 0);  // Couleur du trait
    strokeWeight( 2 ); //Epaisseur du trait
    line(commande.coordonnees_trajectoire_x[i]*SCALE, 
    window_size_y-commande.coordonnees_trajectoire_y[i]*SCALE-HAUTEUR_SOL, 
    commande.coordonnees_trajectoire_x[i+1]*SCALE, 
    window_size_y-commande.coordonnees_trajectoire_y[i+1]*SCALE-HAUTEUR_SOL); 

    // Points rouges
    strokeWeight(8); // Epaisseur du trait
    point(commande.coordonnees_trajectoire_x[i+1]*SCALE, window_size_y-commande.coordonnees_trajectoire_y[i+1]*SCALE-HAUTEUR_SOL);
  }
}

/*
Dessine la trajectoire de la boule en cas de triche
 */
public void draw_trajectoire_triche()
{
  // On fait ici attention de ne pas deborder sur la fin de trajectoire
  for (int i = 0; i < temps && i < commande.instant_fin_commande_triche; i++)
  {

    if(commande.coordonnees_trajectoire_y_triche[i] < 0 && commande.coordonnees_trajectoire_y_triche[i+1] < 0) 
    {
      stroke(51,24,0,170);
      strokeWeight(15);
          line(commande.coordonnees_trajectoire_x_triche[i]*SCALE, 
          window_size_y-commande.coordonnees_trajectoire_y_triche[i]*SCALE-HAUTEUR_SOL, 
          commande.coordonnees_trajectoire_x_triche[i+1]*SCALE, 
          window_size_y-commande.coordonnees_trajectoire_y_triche[i+1]*SCALE-HAUTEUR_SOL); 
    }
        // Dessin de la ligne
    stroke(10, 214, 0,255);  // Couleur du trait
    
    strokeWeight( 2 ); //Epaisseur du trait
    line(commande.coordonnees_trajectoire_x_triche[i]*SCALE, 
    window_size_y-commande.coordonnees_trajectoire_y_triche[i]*SCALE-HAUTEUR_SOL, 
    commande.coordonnees_trajectoire_x_triche[i+1]*SCALE, 
    window_size_y-commande.coordonnees_trajectoire_y_triche[i+1]*SCALE-HAUTEUR_SOL); 

    // Points verts
    strokeWeight(8); // Epaisseur du trait
    point(commande.coordonnees_trajectoire_x_triche[i+1]*SCALE, window_size_y-commande.coordonnees_trajectoire_y_triche[i+1]*SCALE-HAUTEUR_SOL);
  }
}



/*
Dessine la boule
 */
public void draw_boule()
{
  stroke(80, 80, 80);  // Couleur du trait
  strokeWeight(2);
  fill(80, 80, 80);

  if (GAME_STATE == INIT_LANCER)
    ellipse(0*SCALE, window_size_y-HAUTEUR_INITIALE*SCALE-HAUTEUR_SOL-6, 20, 20); 
  else
    ellipse(position_boule_x*SCALE, window_size_y-position_boule_y*SCALE-HAUTEUR_SOL-6, 20, 20);
}

/*
Dessine des vecteurs de poussee autour de la boule
 */
public void draw_reacteurs()
{

  strokeWeight(4);
  stroke(255, 150, 58);
  fill(255, 0, 0);

  //ellipse(0*SCALE, window_size_y-HAUTEUR_INITIALE*SCALE-HAUTEUR_SOL-5, 10, 10); 
  drawArrow( (int) (position_boule_x*SCALE), (int) ( window_size_y-position_boule_y*SCALE-HAUTEUR_SOL-5 ), 
  (int) (position_boule_x*SCALE), (int) ( (window_size_y-position_boule_y*SCALE-HAUTEUR_SOL-5)-50*commande.vitesse_trajectoire_y[temps]) );

  drawArrow( (int) (position_boule_x*SCALE), (int) ( window_size_y-position_boule_y*SCALE-HAUTEUR_SOL-5 ), 
  (int) ( (position_boule_x*SCALE) + 50*commande.vitesse_trajectoire_x[temps] ), (int) ( window_size_y-position_boule_y*SCALE-HAUTEUR_SOL-5 ) );
}


/*
* Dessine le cochonnet !
 */
public void draw_cochonnet()
{
  stroke(0, 0, 0);  // Couleur du trait
  strokeWeight(2);
  fill(255, 51, 51);
  ellipse(position_cochonnet*SCALE, window_size_y-HAUTEUR_SOL, 8, 8);
}



/**
 * Dessine le vecteur vitesse initiale
 */
public void drawSpeedVector() {
  stroke(0, 0, 255);  // Couleur du trait
  strokeWeight(4); //Epaisseur du trait
  drawArrowPolar(0*SCALE, PApplet.parseInt(window_size_y-HAUTEUR_INITIALE*SCALE-HAUTEUR_SOL-5), PApplet.parseInt(player_force*20), PApplet.parseInt(player_angle_dattaque));
}

/**
 * Dessine un vecteur en coordon\u00e9es polaires avec rep\u00e8re invers\u00e9 selon les y
 */
public void drawArrowPolar(int x_origine, int y_origine, int r, int theta) {
  drawArrow(x_origine, y_origine, x_origine + PApplet.parseInt(r*cos(radians(theta))), y_origine - PApplet.parseInt(r*sin(radians(theta))));
}

/**
 * Dessine un vecteur en coordon\u00e9es cart\u00e9siennes
 */
public void drawArrow(int x1, int y1, int x2, int y2) {
  line(x1, y1, x2, y2);
  pushMatrix();
  translate(x2, y2);
  float a = atan2(x1-x2, y2-y1);
  rotate(a);
  line(0, 0, -10, -10);
  line(0, 0, 10, -10);
  popMatrix();
}

/*
Draw the texts
 */
public void draw_texts()
{
  if (GAME_STATE == LANCER_BOULE || GAME_STATE == END_GAME || GAME_STATE == INIT_LANCER)
  {
    textSize(15);
    textAlign(LEFT, CENTER);
    fill(0, 0, 0);
    text("X: " + nf(position_boule_x, 1, 2), 720, 30);
    text("Y: " + nf(position_boule_y, 1, 2), 720, 50); 

    text("Vx: " + nf(commande.vitesse_trajectoire_x[temps], 1, 2), 630, 30);
    text("Vy: " + nf(commande.vitesse_trajectoire_y[temps], 1, 2), 630, 50); 



    fill(0, 0, 0);
    textAlign(LEFT);
    textSize(15);
    text("Time:" + PApplet.parseInt(temps) + " periods", 410, 65);
    text("Balls      :", 20, 100); 
    text("Strengh : " + nf(player_force, 1, 1) + "m/s", 20, 120);
    text("Angle    : " + PApplet.parseInt(player_angle_dattaque) + "\u00b0", 20, 140); 

    // Le nombre de balles restantes
    fill(64);
    strokeWeight(0); //Epaisseur du trait
    for (int i = 0; i < lancers_restants; i++)
      ellipse(95+15*i, 95, 10, 10);


    textAlign(LEFT);
    fill(20, 20, 51);

    textSize(20);
    if (CHEAT_MODE) text("Open Loop", 410, 35); 
    else  text("Manual", 410, 35);
  } else
  {
    textSize(15);
    textAlign(CENTER, CENTER);
    text("ERROR draw_texts()", 400, 20); 
    fill(0, 0, 0);
  }
}


public void draw_legende()
{
  image(legende_img, 0, 0);
}



/*
Les variables et constantes de jeu utilisees dans tout le programme
 * Maxime Touroute
 * Nicolas Sintes
 * Vincent Montalieu
 * Avril 2015
 */
/************* Constantes de jeu ****************/

// Etats du programme

int GAME_STATE;
int START_MENU = 1;
int INIT_LANCER = 3; // Moment o\u00f9 on choisit la vitesse et l'angle d'attaque
int LANCER_BOULE = 4; // Moment o\u00f9 la boule est lanc\u00e9e
int END_GAME = 10; // Moment o\u00f9 la boule est lanc\u00e9e

// Le mode triche
boolean CHEAT_MODE = false;

// La hauteur du sol
int HAUTEUR_SOL = 65; 

// La hauteur initiale du lancer
float HAUTEUR_INITIALE = 1.0f;


// Le nombre de tentatives pour chaque lancer
int nombre_lancers = 3;
int lancers_restants = 0;

/************ Donn\u00e9es du jeu ************/

PImage background_img;
PImage legende_img;
PImage menu_img;
PImage menu_x;
PImage menu_background;


int temps=0;

Commande commande = new Commande();



/* Donn\u00e9es du joueur */
float player_force = 0;
float player_angle_dattaque = 0;
float position_boule_x;
float position_boule_y;
float score;
float position_cochonnet;

/**************************************/




/*
  L'intelligence du jeu
 * Maxime Touroute
 * Avril 2015
 */
/*

 
 * Cr\u00e9ation du jeu
 */
public void setup_game()
{
  init_player_data();
  setup_sound();
  play_music(); 
  temps = 0;
  menu_img = loadImage("menu.png");
  menu_x = loadImage("menu_x.png");
  menu_background = loadImage("menu_background.png");
  GAME_STATE = START_MENU;
}

/*
 * Initialiser les variables pour une nouvelle partie
 */
public void init_game() {
  // Chargement du background
  background_img = loadImage("Background.jpg");
  legende_img = loadImage("tableau_de_bord.png");
  temps = 0;
  // On r\u00e9initialise pas les param\u00e8tres du joueur (force et angle d'attaque)
  score = 0;

  // On retire un lancer si necessaire
  if (lancers_restants == 0)
  {

    init_cochonnet();
    lancers_restants = nombre_lancers;
  }
  lancers_restants--;

  init_boule();

  GAME_STATE = INIT_LANCER; // On enchaine sur l'init lancer
}


/*
Initialise les donn\u00e9es li\u00e9es au joueur
 */
public void init_player_data()
{
  player_force = 5;
  player_angle_dattaque = 45;
}

public void init_boule()
{
  position_boule_x = 0;
  position_boule_y = HAUTEUR_INITIALE;
}

public void init_cochonnet()
{
  position_cochonnet = random( 3, 10);
}

public void update_game()
{
  // Le d\u00e9part de lancement de la boule
  if (GAME_STATE == INIT_LANCER)
  {
  } else if (GAME_STATE == LANCER_BOULE)
  {
    // On avance dans le d\u00e9placement
    temps++;

    if (commande.coordonnees_trajectoire_y[temps] <= 0) commande.coordonnees_trajectoire_y[temps] = 0; // on arrondit le y.

    // Update de la position courante de la boule
    if (CHEAT_MODE && temps <= commande.instant_fin_commande_triche)
    {

      position_boule_x = commande.coordonnees_trajectoire_x_triche[temps];
      position_boule_y = commande.coordonnees_trajectoire_y_triche[temps];
    } else if (!CHEAT_MODE)
    {
      position_boule_x = commande.coordonnees_trajectoire_x[temps];
      position_boule_y = commande.coordonnees_trajectoire_y[temps];
    }


    // Lorsque que la boule a touchee le sol
    if ( (!CHEAT_MODE && position_boule_y <= 0) || (CHEAT_MODE && temps > commande.instant_fin_commande_triche) ) // Si fin de la trajectoire, fin de la partie
    {
      // Update the score
      float distance_max = 7;
      float distance = abs(position_cochonnet - position_boule_x);
      score = 0;

      if (distance/distance_max < 1) score = 100 -  100*((distance/distance_max));
      if (score > 98) score = 100;

      print("boule", position_boule_x, "cochonnet", position_cochonnet, "score", score, "\n");
      play_score_fx();

      draw_game(); // Dessine une derni\u00e8re fois la sc\u00e8ne

        GAME_STATE = END_GAME;
      compteur_dessin = 0;
    }
  } else if (GAME_STATE == END_GAME)
  {
  }
}

/* Gestion du son 
 *  Maxime Touroute
 * Avril 2015
 */



Minim music_minim;
Minim roll_fx_minim;
Minim score_fx_minim;

AudioPlayer music_player;
AudioPlayer roll_fx_player;
AudioPlayer score_fx_player;


public void setup_sound()
{
  music_minim = new Minim(this);
  roll_fx_minim = new Minim(this);
  score_fx_minim = new Minim(this);

  roll_fx_player = roll_fx_minim.loadFile("fx_choc.mp3", 1024);
}

public void play_music()
{
  music_player = music_minim.loadFile("theme_music.mp3", 1024);
  music_player.play();
}

public void play_roll_fx()
{  
  roll_fx_player.play();
}
public void play_score_fx()
{
  // Son diff\u00e9rent selon le score
  if(CHEAT_MODE) score_fx_player = music_minim.loadFile("fx_score_cheat.mp3", 1024);
  else if (position_boule_x*SCALE > window_size_x+10) score_fx_player = music_minim.loadFile("fx_score_outofbounds.mp3", 1024);
  else if (score < 65)
    score_fx_player = music_minim.loadFile("fx_score_1.mp3", 1024);
  else if (score < 95)
    score_fx_player = music_minim.loadFile("fx_score_2.mp3", 1024);
  else
    score_fx_player = music_minim.loadFile("fx_score_3.mp3", 1024);

  score_fx_player.play();
}

public void stop_sound()
{ 
  music_player.close();
  music_minim.stop();

  roll_fx_player.close();
  roll_fx_minim.stop();

  score_fx_player.close();
  score_fx_minim.stop();
  super.stop();
}

/* Donn\u00e9es de fen\u00eatre et d'affichage 
 * Maxime Touroute
 * Avril 2015
 */


// Taille de la fen\u00eatre
int window_size_x = 800;
int window_size_y = 450;
int framerate = 30;

// Valeur d'\u00e9chelle pour la conversion rep\u00e8re r\u00e9el - rep\u00e8re fen\u00eatre
int SCALE = 80;

  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "PetanqueSimulator" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
